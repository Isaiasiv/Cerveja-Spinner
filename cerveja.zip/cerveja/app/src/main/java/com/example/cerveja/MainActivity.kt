package com.example.cerveja

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val expertCerveja = ExpertCerveja()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // Certifique-se de que o layout seja o activity_main.xml

        val spinner: Spinner = findViewById(R.id.spinnerCerveja)
        val button: Button = findViewById(R.id.buttonBuscar)
        val textView: TextView = findViewById(R.id.textViewMarcas)

        button.setOnClickListener {
            val tipoSelecionado = spinner.selectedItem.toString()
            val marcas = expertCerveja.getMarcas(tipoSelecionado)
            textView.text = marcas.joinToString(", ")
        }
    }
}
